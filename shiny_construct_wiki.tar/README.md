# Construct Wiki (viewer) for ARI2

Project was originally on: https://github.com/bi-sdal/construct_wiki

It can be viewed on the SDAD server here: http://sdad.policy-analytics.net:3838/sdad/construct_wiki/

# Data

The data was all stored on the older VT SDAL Google Drive:
https://drive.google.com/drive/folders/0B48s6gBxuTwjeW5UQVRYOV92Q2s?usp=sharing

This folder is currently set with anyone with the link can edit the contents.

The way this was originally setup was to have a Google Form feed the underlying dataset.
However this Form is not longer valid since the dataset the form was updating was copied and altered.
So, if the form is used, you will have different entries between the older and newer forms.

The newer dataset was created by Viki in order to consolidate, fix, and standardize the constructs.

You can see the download URLs of the dataset in the `global.R` file,
where `ORIGINAL_DATA` is the original data fed by the Google form (again, this data and form should not be used anymore),
and the `ADJUSTED_DATA` is the newly cleaned up constructs Viki updated.

# App Comments

The `global.R` file downloads the `ORIGINAL_DATA` and `ADJUSTED_DATA` files everytime the app is loaded.
This was to silently update the data the application shows without having to do a data pull,
and the application would more or less be a live update.

# Setup

install packages used in the application.


```r
install.packages(c('shiny', 'testthat', 'readr', 'DT', 'visNetwork', 'dplyr', 'stringr', 'igraph',
                   'shinydashboard', 'here', 'R.utils'))
```

# Deployment

You need to `pull` the latest project into the SDAD shiny server for the changes to be live on the server.
In the `shiny` container, the project is located in `/srv/shiny-server/sdad/construct_wiki`.
Depending on who is doing the deployment, you will need to either `add` another remote, or change the `origin` target.

```bash
git remote add origin http://chend@gitlab:30080/sdad/construct_wiki.git
```

Where chend would be ther person doing the deployment.

Note, this URL is different from the URL provided by Gitlab.
This has to do with how the Docker DNS finds other Docker containers by name.

You can also setup SSH keys, but that would need to be setup in a docker volume just in case the container is restarted.
