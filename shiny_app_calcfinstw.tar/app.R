
library(shinydashboard)
library(dashboardthemes)
library(dplyr)
library(readr)
library(leaflet)
library(sf)
library(plotly)
library(shinyjs)
library(rintrojs)
library(shinyBS)
library(shinyWidgets)
library(DT)
library(RColorBrewer)
library(stringr)
library(shinyalert)
library(shiny)
library(jrvFinance)
library(FinCal)
library(scales)
library(ggplot2)

#expenditures by county in VA
# expend_raw <- read_csv('~/Documents/STW/data/expenditures_county_va.csv')
# #cost of community colleges in VA: Nursing
# cost_cc <- read_csv('~/Documents/STW/data/cost_cc_va.csv')
# #earnings neede from MIT Living wage, 2 counties
# earnings_raw <- read_csv('~/Documents/STW/data/wage_county_va.csv')
# #earnings by county and education level
# earnings_acs <- read_csv('~/Documents/STW/data/earnings.csv')
# #eanings according to different community college and careers from onet
# earnings_cc <- read_csv("~/Documents/STW/data/earnings_cc_VA_onet.csv")

expend_raw <- read_csv('expenditures_county_va.csv')
#cost of community colleges in VA: Nursing
cost_cc <- read_csv('cost_cc_va.csv')
#earnings neede from MIT Living wage, 2 counties
earnings_raw <- read_csv('wage_county_va.csv')
#earnings by county and education level
earnings_acs <- read_csv('earnings.csv')
#eanings according to different community college and careers from onet
earnings_cc <- read_csv("earnings_cc_VA_onet.csv")



ui <- fluidPage(
  
  dashboardHeader(
    
    titleWidth='100%',
    title = h2("Financial Planning for a Skilled Technical Workforce Career", align = "center")
    
  ),
  
  dashboardBody(
    
    #column 1
    column(title = h2("Somethign"),
           style = "height:300px;background-color:skyblue",
           width = 3,
           box(width = 12,
               title = strong("Location and status")
           ),
           
           
           
           #Select the county
           selectInput('county', "Select the name of your county/city",
                       choices = c(
                         'Arlington',
                         'Albemarle'
                       ),
                       selected = 'Arlington'
           ), 
           
           #status adult
           selectInput('status', "Choose your status at home",
                       choices = c(
                         '1 adult',
                         '2 adult 1 work',
                         '2 adult 2 work'
                       ),
                       selected = '1 adult'
           ), 
           
           #number children
           selectInput('children', "Indicate the number of children",
                       choices = c(
                         '0child',
                         '1child',
                         '2child',
                         '3child'
                       ),
                       selected = '0child'
           )
    )
    , 
    
    
    #Column 2
    #Select the community college to determine costs
    
    column(title = "Somethign",
           style = "height:300px;background-color:pink",
           width = 3,
           box(width = 12,
               title = strong("School and Career")
           ),
           selectInput(
             'ccollege', "Select a Community College",
             choices = 
               c(
                 'Blue Ridge',
                 'Lancaster',
                 'Danville',
                 'Germanna',
                 'John Tyler',
                 'Lord Fairfax',
                 'Mountain Empire',
                 'New River',
                 'Northern Virginia',
                 'Patrick Henry',
                 'Paul D. Camp',
                 'Piedmont',
                 'Rappahannock',
                 'Reynolds',
                 'Southside Virginia',
                 'Southwest Virginia',
                 'Thomas Nelson',
                 'Tidewater',
                 'Virginia Highlands',
                 'Virginia Western',
                 'Wytheville'
               )
             #cost_cc$Institution
             # ,
             # selected = 'Northern Virginia'
           ),
           
           selectInput(
             'program', "Choose a program", 
             # choices = c(
             #   'AAS',
             #   'Career Studies Certificate',
             #   'Certificate'
             # )
             choices = "", selected = ""
           ), 
           
           selectInput(
             'degree', "Choose a degree", 
             # choices = c(
             #   'Advanced Emergency Medical Technician',
             #   'Advanced Health Care',
             #   'Associate Degree of Applied Science',
             #   'Associate in Applied Science',
             #   'Associate of Applied Science Degree',
             #   'Associate of Applied Science Nursing',
             #   'Basic Life Support (BLS) for Healthcare Providers CPR',
             #   'Certified Nurse Aide (WCG)',
             #   'Certified Nurse Aide Bridge',
             #   'Certified Phlebotomy Technician',
             #   'Clinical Medical Assistant',
             #   'Clinical Medical Assistant (WCG)',
             #   'Emergency Medical Services',
             #   'Emergency Medical Services (EMT)',
             #   'Emergency Medical Technician',
             #   'Health Sciences',
             #   'Health Technology: Pre-Nursing',
             #   'Healthcare Technician',
             #   'Introduction to Practical Nursing',
             #   'Medical Coding Foundations I CSC',
             #   'Nurse Aide',
             #   'Nurse Aide CSC',
             #   'Nurse Aide Extended Care',
             #   'Nurse Aide Preparation (CNA)',
             #   'Nurse Aide Program',
             #   'Nurse Aide Training',
             #   'Nurse Aide/Medication Aide',
             #   'Nursing',
             #   'Nursing Assistant',
             #   'Patient Care Technician (includes Medication Aide and Nurse Aide)',
             #   'Pharmacy Technician',
             #   'Pharmacy Technician (WCG)',
             #   'Phlebotomy',
             #   'Phlebotomy - Health Science I (Nurse Aide, Phlebotomy)',
             #   'Phlebotomy Career Studies Certificate',
             #   'Phlebotomy Technician',
             #   'Phlebotomy Technician with Clinical Rotation (WCG)',
             #   'Practical Nursing',
             #   'Practical Nursing Certificate',
             #   'Pre Nursing',
             #   'Pre-Allied Health Advanced Nurse Aide',
             #   'Registered Nursing',
             #   'Surgical Scrub Nursing'
             # ), 
             # selected = 'Nursing'
             choices = "", selected = ""
             
           )
           
    ), 
    
    
    #column 3
    column(title = "Somethign",
           style = "height:300px;background-color:khaki",
           width = 3,
           box(width = 12,
               title = strong("Payment options")
               
           ),
           
           #------
           checkboxInput(inputId = "ccpayment",
                         label = strong("Add college payments per year"),
                         value = FALSE),
           
           # Display this only if payment is chosen
           conditionalPanel(condition = "input.ccpayment == true",
                            textOutput("text")
           ),
           
           checkboxInput(inputId = "debt",
                         label = strong("Add debt payments over 10 years"),
                         value = FALSE),
           
           # Display this only if debt is chosen 
           conditionalPanel(condition = "input.debt == true",
                            sliderInput(inputId = "debtpercentage",
                                        label = "Percentage of debt:",
                                        min = 0, max = 1, value = 0.9, step = 0.1),
                            textOutput("text_payment")
           )
           
           #-------
           
           
           
    ),
    
    #column 4
    column(title = h2(""),
           style = "height:300px;background-color:paleturquoise",
           width = 3,
           box(width = 12,
               title = strong("Job and Post-graduation")
           ),
           
           #--- new
           checkboxInput(inputId = "earnings_career",
                         label = strong("View earnings after completion of credential"),
                         value = FALSE),
           
           # Display this only if debt is chosen 
           conditionalPanel(condition = "input.earnings_career == true",
                            
                            selectInput(
                              'job', "Choose a job", 
                              
                              choices = "", selected = ""
                            )
           )
           
           
           #--
           
           
           
           
           
    )
    
    
    
    
    # selectInput(
    #   'ccollege', "Select a Community College",
    # 
    #     cost_cc$Institution
    # 
    #   , 
    #   selected = 'Northern Virginia'
    # ),
    
    
    #Select program, AAS Associate of Arts in Science
    
    #Select the specific degree,
    
    
    
    #----
    
    
    #----
    
    #,
    
    # sliderInput(inputId = "debtpercentage",
    #             label = "Percentage of debt:",
    #             min = 0, max = 1, value = 0.9, step = 0.1) 
    
    
  ),
  br(),
  
  dashboardBody(
    
    fluidRow(
      
      box(width = 12,
          title = " ", align= "center",
          # width = 12,
          plotlyOutput("plot" , width = "auto" ,  height = "500")
      )
      
    ),
    
    
    #plotlyOutput("plot")   
    #)
    #)
    #---
    br(),
    br(),
    
    fluidRow( 
      column(
        width = 8, align="center", height = 100,
        style = "height:100px;background-color:gray63",
        htmlOutput("catch_up_year")
      )
    ),
    
    fluidRow(
      #box(width = 12,
      
      column(width = 6, 
             style = "height:150px;background-color:lightcyan",
             # box(title = "Plan your career for the next years",
             #     width = 12,
             box(width = 10,
                 title = strong("Money Gains with High School Only over time"),
                 textOutput("text_irr_hs"), 
                 br()
                 # ,
                 # htmlOutput("catch_up_year") 
                 
             )
             
      ),
      
      column(width = 6, 
             style = "height:150px;background-color:peachpuff",
             box(width = 10,
                 title = strong("Money Gains with Technical Credential over time"), 
                 textOutput("text_irr_assoc") 
             )
             
      )
      
      #)
      
    )
    
    
    
  )
  
  #to see tables
  , 
  # fluidRow(
  #   
  # tableOutput(
  #   "table3"
  # )
  #   
  # )
  
  
)

server <- function(input, output, session) {
  
  #SECTION ON updateSelectInput
  #choose college to restrict the amount of programs
  observeEvent(
    input$ccollege,
    updateSelectInput(session, "program", "Select a program", 
                      choices = cost_cc$Program[cost_cc$Institution==input$ccollege]))
  
  #choose programs to restrict the amount of degrees  
  observeEvent(
    input$program,
    updateSelectInput(session, "degree", "Select a degree", 
                      choices = cost_cc$`Exact title`[cost_cc$Program==input$program & cost_cc$Institution==input$ccollege]))
  
  #choose college to restrict the amount career --> salaries
  observeEvent(
    input$ccollege,
    updateSelectInput(session, "job", "Select the most appropiate job", 
                      choices = earnings_cc$program[earnings_cc$college==input$ccollege]))
  
  #--------
  
  
  
  library(blscrapeR)
  df <- inflation_adjust(1995)
  #inflation <- (mean(df$adj_value[(nrow(df)-10):nrow(df)]))/100
  inflation<- 0.013
  #inflation<- 0.013
  #year of community college
  year_cc <- 2
  #--------
  
  
  #############################################################################################################
  # EXPENDITURES 
  #############################################################################################################
  
  #------------------------------------------------------------------------------------------------------------
  #PERSONAL expenditures 
  #------------------------------------------------------------------------------------------------------------   
  library(reshape2)
  expend_raw_long <-  melt(expend_raw, id.vars=c("county" ,  "category" , "item"  ,   "adults"))
  
  personal_exp <- reactive({ expend_raw_long %>% filter(county==input$county, category=="expenditure", item=="Required annual income before taxes", adults==input$status, variable == input$children ) %>% select(value) }) 
  
  personal <- reactive({ data.frame( personal= cumprod( c(personal_exp(), rep(c(1+inflation), years )))  )  })  
  
  
  output$data <- renderTable({
    personal()
  })
  
  #------------------------------------------------------------------------------------------------------------
  #COLLEGE expenditures 
  #------------------------------------------------------------------------------------------------------------   
  
  tuition_cc <- reactive({ cost_cc %>% filter(`Exact title`== input$degree, Program==input$program, Institution==input$ccollege ) %>% select("Tuition/costs credits")  }) 
  other_costs <- 3500  #other costs, including uniforms,  stetoscope, etc 
  total_cc <- reactive({ tuition_cc() + other_costs }) 
  tot_cost_cc_year <- reactive({ total_cc()/year_cc  }) 
  
  #community college expenditures: includes tuition and other costs
  #expend_coll <- dat
  
  college <-  reactive({ data.frame( college= as.numeric( c( tot_cost_cc_year(), tot_cost_cc_year(), rep(0, 43 -year_cc)) )  )  })  
  
  
  output$data1 <- renderTable({
    college()
    
  })
  
  #------------------------------------------------------------------------------------------------------------
  #DEBT expenditures 
  #------------------------------------------------------------------------------------------------------------   
  
  tuition_cc <- reactive({ cost_cc %>% filter(Institution==input$ccollege, Program==input$program, `Exact title`== input$degree) %>% select("Tuition/costs credits") }) 
  other_costs <- 3500  #other costs, including uniforms,  stetoscope, etc 
  total_cc <-  reactive({ tuition_cc() +other_costs })
  final_debt <-  reactive({ total_cc()*input$debtpercentage })
  interest_rate <- 0.0466  #annual interest rate
  years <- 42
  years_debt <- 10
  
  debt_pmt <- reactive({ pmt(r = interest_rate, n = years_debt, pv = final_debt(), fv = 0) })  
  #result of payment pmt comes negative so, use negative to adjust the sign
  debt <- reactive({ data.frame( debt= as.numeric( c( rep(0,year_cc) , rep(-debt_pmt(), years_debt), rep(0, years-year_cc -years_debt +1) ) )    )  }) 
  
  output$data2 <- renderTable({
    debt()
    
  })
  
  
  
  
  
  #############################################################################################################
  # EARNINGS 
  #############################################################################################################
  
  #------------------------------------------------------------------------------------------------------------
  #MINIMUM WAGE EARNINGS
  #------------------------------------------------------------------------------------------------------------   
  #earnings_raw <- read_csv('~/Documents/STW/data/wage_county_va.csv')
  # minwage_hour <-  earnings_raw %>% filter(county=="Arlington", category=="wage", 
  #                           item=="Minimum Wage", adults=="1 adult") %>% select(value="0child")
  
  minwage_hour <- reactive({ earnings_raw %>% filter(county==input$county, category=="wage", 
                                                     item=="Minimum Wage", adults=="1 adult") %>% select(value="0child")  }) 
  
  index_minwage<- 0
  hoursweek <- 43.34  #determined from MIT labwage
  weeks <- 4
  months <-  12
  #initialize the matrix 1
  
  minwage <- reactive({ data.frame(minwage= cumprod(c(minwage_hour()*hoursweek*weeks*months, rep(c(1+index_minwage), years ))) )   }) 
  #minwage()
  
  #------------------------------------------------------------------------------------------------------------
  #HIGH SCHOOL EARNINGS 
  #------------------------------------------------------------------------------------------------------------   
  #earnings_acs <- read_csv('~/Documents/STW/data/earnings.csv')
  
  #earnings_hs <- earnings_acs %>% filter(county =="Arlington") %>% select(earnings_hs) 
  earnings_hs <- reactive({ earnings_acs %>% filter(county ==input$county) %>% select(earnings_hs)  })  
  earngr_hs <- 0.018   #growht of earnings for hs 2012-2018
  highschool <- reactive({ data.frame( highschool= cumprod(c( earnings_hs() , rep(c(1+earngr_hs), years ))) )    })    #revise the growth PENDIENTE
  
  
  
  #------------------------------------------------------------------------------------------------------------
  #ASSOCIATE EARNINGS 
  #------------------------------------------------------------------------------------------------------------   
  # earnings_cc_career <-  earnings_cc %>% filter(college== 'Northern Virginia Community College') %>%
  #   #filter(years==1.5) %>% filter( program == 'input$career' ) %>%  select(wagemedian)
  #   filter( program == "Registered Nursing/Registered Nurse" ) %>% filter(years==1.5) %>% select(wagemedian)
  
  # earnings_cc_career <- reactive({ earnings_cc %>% filter(college== input$ccollege) %>%
  #     filter( program == input$degree ) %>% filter(years==1.5) %>% select(wagemedian)  }) 
  earnings_cc_career <- reactive({ earnings_cc %>% filter(college== input$ccollege,  years==1.5, program == input$job) %>% select(wagemedian)  }) 
  
  earngr_assoc <- 0.01   #growht of earnings for hs 2012-2018
  
  assoc0 <- reactive({ data.frame( assoc0 = cumprod(c(earnings_cc_career() , rep(c(1+earngr_assoc), years )))  ) })  
  assoc <- reactive({  data.frame( assoc = c(0,0, assoc0()[3:43,1] )  )     })
  
  
  output$data33 <- renderTable({
    # assoc()[1,1] <- 0
    # assoc()[2,1] <- 0
    assoc()
    
  }) 
  
  
  #------------------------------------------------------------------------------------------------------------
  #JOIN DATA - expenditures 
  #------------------------------------------------------------------------------------------------------------   
  
  dat_plot <- reactive({ cbind(personal(), college(), debt(), minwage(), highschool(), assoc() ) }) 
  
  
  output$data3 <- renderTable({
    
    highschool()
    
  }) 
  
  #--------------------------------------------------------
  #PLOT
  #-------------------------------------------------------- 
  
  
  output$plot <- renderPlotly({
    
    colors <- c("Personal Expenses"="darkred", 
                "College Expenses"= "red",
                "Debt"="orange", 
                "Minimum Wage Earnings"= "yellow4",
                "High School Earnings"="royalblue3",
                "Associate Earnings"="blue"
    )
    
    
    plot1 <- ggplot(dat_plot(), aes(x= seq(0,years) ) ) +
      
      geom_line(aes(y = personal , color = "Personal Expenses" ), size=0.6, alpha=1 ) +
      geom_line(aes(y = minwage , color = "Minimum Wage Earnings" ), size=0.6, alpha=1 ) +
      geom_line(aes(y = highschool , color = "High School Earnings" ), size=0.6, alpha=1 ) +
      #geom_line(aes(y = assoc , color = "Associate Earnings" ), size=0.6, alpha=1 ) +
      
      labs(x = "Years",
           y = "Dollars",
           color = "Legend") +
      scale_color_manual(values = colors) +
      ggtitle("Personal Expenses and Earnings for 40 years")+
      theme(plot.title = element_text(hjust = 0.5)) +
      scale_x_continuous(breaks= seq(0, years, by = 5)) +
      scale_y_continuous( breaks=seq( 0, 130000, by = 10000 ) , labels = comma)
    #max(dat_plot())
    plot1
    
    #--- new 
    
    if(input$earnings_career == TRUE){
      plot1 <- plot1 +
        geom_line(aes(y = assoc , color = "Associate Earnings" ), size=0.6, alpha=1 )
      
    }
    
    plot1
    #-----   
    
    if(input$ccpayment == TRUE){
      plot1 <- plot1 +
        geom_line(aes(y = personal+ college , color = "College Expenses" ), size=0.6, alpha=1 )
      
    }
    
    plot1
    
    if(input$debt == TRUE){
      plot1 <-plot1 +
        geom_line(aes(y = personal+ debt , color = "Debt" ), size=0.6, alpha=1 )
    }
    
    plot1
    
  })
  
  
  #Text
  
  #add text
  output$text <- renderText({
    paste("First year:",
          tot_cost_cc_year(),
          "Second year: $", 
          tot_cost_cc_year() )
    
  })
  
  #how much per year if loan 
  
  output$text_payment <- renderText({
    paste("Anual payment:",
          round(-debt_pmt() , 2)
    )
    
  })
  
  #Internal rate of return and Net Present Value
  
  #NET RESULTS
  #HIGH SCHOOL
  # flows_hs <- reactive({ highschool() - personal()    }) 
  # #internal rate of return
  # irr_hs <- reactive({ round(irr(flows_hs() ), 4 )*100 }) 
  # #net present value
  # rate <- 0.08
  # npv_hs <- reactive({ npv(r = rate, cf = c(flows_hs() ))  }) 
  
  
  rate <- 0.08
  # flows_hs <- reactive({ dat_plot()$highschool - dat_plot()$personal    }) 
  # #internal rate of return
  # irr_hs <- reactive({ round(irr(flows_hs() ), 4 )*100 }) 
  # #net present value
  # 
  # npv_hs <- reactive({ npv(r = rate, cf = c(flows_hs() ))  })
  
  flows_hs <- reactive({ dat_plot()$highschool - dat_plot()$personal    }) 
  #internal rate of return
  irr_hs <- reactive({ round(irr(flows_hs() ), 4 )*100 }) 
  #net present value
  
  npv_hs <- reactive({ npv(r = rate, cf = c(flows_hs() ))  })
  
  output$text_irr_hs <- renderText({
    
    # flows_hs <-  plot_dat$earnings_hs - plot_dat$personal
    # #internal rate of return
    # irr_hs <- round(irr(flows_hs), 4 )*100  
    # #net present value
    # npv_hs <- npv(r = rate, cf = c(flows_hs))
    
    
    
    paste("Internal Rate of Return:",
          
          irr_hs(),"%" )
    
  })
  
  
  
  #ASSOCIATE CREDENTIAL
  
  
  
  
  flows_assoc <-  reactive({ dat_plot()$assoc - dat_plot()$personal    })
  #internal rate of return
  irr_assoc <-  reactive({ round(irr(flows_assoc() ), 4 )*100  }) 
  #net present value
  #npv_assoc <- reactive({ npv(r = rate, cf = c(flows_assoc() )) })
  
  
  output$text_irr_assoc <- renderText({
    
    paste("Internal Rate of Return:",
          irr_assoc(),"%" )
    
  })
  
  
  #estimate the year when earnings_hs catch up with expenses
  #difference <- min(abs(flows_hs)) 
  
  
  # catch_up <- which.min(abs(flows_hs))
  #  years
  # dat[catch_up, 2]
  
  catch_up <- reactive({ which.min(abs(flows_hs() ))  })  
  
  year_catch <- reactive({ dat[catch_up(), 2]  } ) 
  
  output$catch_up_year <- renderText({
    
    paste("If the individual starts working after high school (18 years old), he/she will completely cover expenses <b> ONLY after "
          ,"28 years </b>", "that is, only after he/she turns", "<b>", 46,"</b>." )
    
  })
  
  
  output$table3 <- renderTable({
    
    highschool()- personal()
    
  })
  
  
  
  
  
}

shinyApp(ui, server)