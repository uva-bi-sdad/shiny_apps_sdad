#dashboard for choosing category of expenditures

library(shiny)
library(readxl)
library(dplyr)
library(shinydashboard)
library(dashboardthemes)
library(readr)
library(leaflet)
library(sf)
library(plotly)
library(shinyjs)
library(rintrojs)
library(shinyBS)
library(shinyWidgets)
library(DT)
library(RColorBrewer)
library(stringr)
library(shinyalert)
library(jrvFinance)
library(FinCal)
library(scales)
library(ggplot2)
library(grid)  #for gridtree


#load data. source: Self Sufficiency Standard http://www.selfsufficiencystandard.org/
#sss_va <- read_excel("~/STW/VA2021_all_families.xlsx", sheet = "SSS", skip = 8)

#sss_va <- read_csv("/sfs/qumulo/qhome/cpm9w/STW/VA2021_all_families.csv",  skip = 8)

sss_va <- read_csv('~/STW/data/VA2021_all_families.csv',  skip = 8)


#CONTRIBPOL2020 <- read_csv("EM/gates/contrib_pol/CONTRIBPOL2020.csv")

#cost <- read_excel("~/Documents/STW/CALCULATOR/data/educ_costs/educ_costs_inventory.xlsx", sheet = "Sheet1")

#new final database
#list.careers <- read_excel("~/Documents/STW/CALCULATOR/data/educ_costs/educ_costs_inventory.xlsx", sheet = "final_inventory")
#cost <- read_csv("/sfs/qumulo/qhome/cpm9w/STW/educ_costs_inventory.csv")
cost <- read_csv('~/STW/data/educ_costs_inventory.csv')



choice.career <- as.list(cost$field)

#expenditures by county in VA
# expend_raw <- read_csv('~/Documents/STW/data/expenditures_county_va.csv')
# #cost of community colleges in VA: Nursing
# cost_cc <- read_csv('~/Documents/STW/data/cost_cc_va_I.csv')
# #earnings neede from MIT Living wage, 2 counties
# earnings_raw <- read_csv('~/Documents/STW/data/wage_county_va.csv')
# #earnings by county and education level
# earnings_acs <- read_csv('~/Documents/STW/data/earnings.csv')
# #eanings according to different community college and careers from onet
# earnings_cc <- read_csv("~/Documents/STW/data/earnings_cc_VA_onet.csv")



ui <- fluidPage(
  
  dashboardBody(
  
    #column1
    column(title = h2(" "),
           style = "height:500px;background-color:#6B979B",
           width = 4,
  
    
  #create categories to select members of family. Options: adult, infant, preschooler, school-age, teenager
  
  
  selectInput(inputId = 'adult' , label = "Number of adults (more than 18 years old)", choices = c("1"="a1", "2"="a2", "3"="a3") ),
  selectInput(inputId = 'infant' , label = "Number of infants (0 to 2 years old)", choices = c("0"="i0", "1"="i1", "2"="i2", "3"="i3", "4"="i4") ),
  selectInput(inputId = 'preschooler' , label = "Number of preschoolers (3 to 5 years old)", choices = c("0"="p0", "1"="p1", "2"="p2", "3"="p3", "4"="p4") ),
  selectInput(inputId = 'school_age' , label = "Number of school-age (6 to 12 years old)", choices = c("0"="s0", "1"="s1", "2"="s2", "3"="s3", "4"="s4") ),
  selectInput(inputId = 'teenager' , label = "Number of teenagers (13 to 18 years old)", choices = c("0"="t0", "1"="t1", "2"="t2", "3"="t3", "4"="t4") ),
  
  selectInput(inputId = 'county' , label = "Select your county", 
              choices = c(
                "Accomack County",
                "Albemarle County",
                "Alexandria city",
                "Alleghany County",
                "Amelia County",
                "Amherst County",
                "Appomattox County",
                "Arlington County",
                "Augusta County",
                "Bath County",
                "Bedford County",
                "Bland County",
                "Botetourt County",
                "Bristol city",
                "Brunswick County",
                "Buchanan County",
                "Buckingham County",
                "Buena Vista city", 
                "Campbell County","Caroline County","Carroll County","Charles City County",
                "Charlotte County","Charlottesville city","Chesapeake city","Chesterfield County", 
                "Clarke County", "Colonial Heights city", "Covington city","Craig County",
                "Culpeper County","Cumberland County","Danville city","Dickenson County",
                "Dinwiddie County","Emporia city","Essex County","Fairfax city","Fairfax County",
                "Falls Church city","Fauquier County","Floyd County","Fluvanna County","Franklin city",
                "Franklin County","Frederick County","Fredericksburg city","Galax city","Giles County",
                "Gloucester County","Goochland County","Grayson County","Greene County",
                "Greensville County","Halifax County","Hampton city","Hanover County","Harrisonburg city",
                "Henrico County","Henry County","Highland County","Hopewell city","Isle of Wight County",
                "James City County","King and Queen County","King George County","King William County",
                "Lancaster County","Lee County","Lexington city","Loudoun County","Louisa County",
                "Lunenburg County","Lynchburg city","Madison County","Manassas city","Manassas Park city",
                "Martinsville city","Mathews County","Mecklenburg County","Middlesex County",
                "Montgomery County","Nelson County","New Kent County","Newport News city","Norfolk city","Northampton County",
                "Northumberland County","Norton ","NottowayCounty","Orange County",
                "Page County","Patrick County","Petersburg city","Pittsylvania County","Poquoson city","Portsmouth city",
                "Powhatan County","Prince Edward County","Prince George County",
                "Prince William County","Pulaski County","Radford city","Rappahannock County",
                "Richmond city","Richmond County","Roanoke city","Roanoke County","Rockbridge County",
                "Rockingham County","Russell County","Salem city","Scott County","Shenandoah County",
                "Smyth County","Southampton County","Spotsylvania County","Stafford County",
                "Staunton city","Suffolk city","Surry County","Sussex County","Tazewell County",
                "Virginia Beach city","Warren County","Washington County","Waynesboro city",
                "Westmoreland County","Williamsburg city","Winchester city","Wise County",
                "Wythe County","York County"
                
              ) 
  )
  
  
    ),
  
  #column2
  column(title = h2(" "),
         style = "height:500px;background-color:#CB623B",
         width = 4,
        
         
#total 832 careers. select input from file



#previouse version
         #degree for field
selectInput(inputId = 'field' , label = "Select a career",
 choices = choice.career
 ),



#type of credential

         selectInput(inputId = 'credential' , label = "Select a credential", 
                     choices = c(
                       "Associate in Applied Science",
                       "Associate in Science",
                       "Certificate",
                       "Career Studies Certificate" )
                     
         ), 
         
         
#community college

         selectInput(inputId = 'ccollege' , label = "Select a Community College", 
                     choices = c(
                       "Blue Ridge",
                       "Central Virginia",
                       "Dabney S. Lancaster",
                       "Danville",
                       "Eastern Shore",
                       "Germanna",
                       "J Sargeant Reynolds",
                       "John Tyler",
                       "Lord Fairfax",
                       "Mountain Empire",
                       "New River",
                       "Northern Virginia",
                       "Patrick Henry",
                       "Paul D Camp",
                       "Piedmont Virginia",
                       "Rappahannock",
                       "Southside Virginia",
                       "Southwest Virginia",
                       "Thomas Nelson",
                       "Tidewater",
                       "Virginia Highlands",
                       "Virginia Western",
                       "Wytheville"
                     ) )
         
         
         
         
  ),

#column 3
column(title = " ",
       style = "height:500px;background-color:#A7BE85",

       width = 4,
       box(width = 12,
           title = strong("Payment options")
           
       ),
       
       #------
       checkboxInput(inputId = "ccpayment",
                     label = strong("Add college payments per year"),
                     value = FALSE),
       
       # Display this only if payment is chosen
       conditionalPanel(condition = "input.ccpayment == true",
                        textOutput("text")
       ),
       
       checkboxInput(inputId = "debt",
                     label = strong("Add debt payments over 10 years"),
                     value = FALSE),
       
       # Display this only if debt is chosen 
       conditionalPanel(condition = "input.debt == true",
                        sliderInput(inputId = "debtpercentage",
                                    label = "Percentage of debt:",
                                    min = 0, max = 1, value = 0.9, step = 0.1),
                        textOutput("text_payment")
       )
       
       #-------
       
       
       
),



tabsetPanel(type = "tab",
            
            tabPanel("Net Price Calculator",
                     fluidRow(
                       
                       box(width = 12,
                           style = "height:500px;background-color:#A5BF86",
                           title = strong("Costs and Financial Aid (Net Price Calculator)"),
                           plotlyOutput("plot_static",width = "auto" ,  height = "500")
                       ),
                       
                       
                       
                       box(width = 12,
                           style = "height:200px;background-color:#B6B6B6",
                           title = strong("Credential costs and Financial Aid"), 
                           h5(" Non-degree credentials include certificates, certifications, licenses, apprenticeships and badges (NCRN, 2020). Three 
                           types of credentials are included in this dashboard, namely, associate degrees, career studies certificates and certificates.
                           Despite the importance of professional credentials, there is not a uniform definition or standard to caterogize them.  However, 
                           number of credits may guide initially a cateorization, where, a career studies certificate has 9-29 hours, 
                           a cerficate has approximately 30-59 semester credit hours, 
                            and an associate degree comprises more than 60 credits."),
                           h5("Credential costs correspond to expenditures that cover the financial cost of a credential offered by a community college, 
                              or an acredited institution. These costs commonly come in two forms: tuition and other costs."),
                           h5(" Tuition is estimated using the information of cost per credit from community colleges in Virginia and multiplied by the 
                              number of credits of the corresponding certification."), 
                           h5("Financial Aid is the summaation of all possible sources of funding coming from federal, state, or local levels. The initial
                              estimation includes the maximum amount from a Pell Grant in 2021: $ 6,345.")
                           
                           # ,
                           # h4("The balance is the difference between Expenses and Financial Aid.", style = "color:white"),
                           # h4("The balance is $ ... ", style = "color:white"),
                           # h4("The balance is the ... % of an average loan in (county) for college education ", style = "color:white")
                          
                           
                           
                       )
                       
                       
                       
                     )
                     
            )
            
            ,
            
            #2nd panel
            tabPanel("Long-term Calculator", 
                     
                     fluidRow(
                       
                           box(width = 12,
                               style = "height:200px;background-color:#A5BF86",
                               title = strong("Personal Expenditures per year"),
                               h4("Personal expenses covering food, housing, child care, transportation, health care, taxes, and miscelaneous, for year 2021"),
                               
                               
                               #textOutput('result'),
                               #textOutput('mean'),
                               textOutput('personal_expenditure') ,
                               h4("College costs per year, includes tuition and fees. Estimated numbers by college cost per credit x number of credits."),
                               textOutput('college_cost') 
                               
                           ), 
                           
                           #plot of time series
                           fluidRow(
                             
                             box(width = 12,
                                 title = " ", align= "center",
                                 # width = 12,
                                 plotlyOutput("plot" , width = "auto" ,  height = "500")
                             )
                             
                           )
                           
                           
                     )
            ),
            
            #3rd panel
            tabPanel("Risk of Dropout", 
                     
                     fluidRow(
                       
                       box(width = 12,
                           style = "height:200px;background-color:#A5BF86",
                           title = strong("Estimating the risk of dropout")
                       )
                     )
            )
            
)

)

)


####################################################################################################################################
# SERVER
####################################################################################################################################


server <- function(input, output, session) {
  
#SECTION ON updateSelectInput
#choose field to restrict the amount of credentials

    observeEvent(
    input$field,
    updateSelectInput(session, "credential", "Select a credential",
                      choices = cost$type[cost$field==input$field]))

#choose credential (program) to restrict  the community college (degree)
  
  observeEvent(
    input$credential,
    updateSelectInput(session, "ccollege", "Select a community college", 
                      choices = cost$ccollege[cost$type==input$credential & cost$field==input$field]))  
  
  
  #####
  
  
  ############################################################ ############################################################  
  
  #####Expeditures 
  
 output$result <-  renderText({paste(input$adult, input$infant,input$preschooler,input$school_age , input$teenager, sep = "" ) } ) 
 # #output$mean <- renderPrint({ as.numeric( sss_va %>% select(var= a1i0p0s0t0 ) %>% summarize( mean(var)) )    })
 # 
 # output$value <- renderPrint({ as.numeric( sss_va  %>% filter( famcode == input$county ) %>% select(var= 'a1i0p0s0t0' ) )    })
 
 
 ## lab
 var_result <- reactive( paste(input$adult, input$infant,input$preschooler,input$school_age , input$teenager, sep = "" ) )
 
 expenditure <- reactive(  as.numeric( sss_va  %>% filter( famcode == input$county ) %>% select(var=  var_result( ) ) )    )
 
 output$personal_expenditure <- renderPrint({
   expenditure()
 })
 
 ############################################################ ############################################################ 

 #costs of Education

 output$college_cost <- renderPrint({
   as.numeric( cost %>% filter( field== input$field, type== input$credential, ccollege== input$ccollege) %>%
                 select( cost_total_est  )   )  
 })
 
 
 ####################
 #Plots 
 
 
 output$plot_static <- renderPlotly({
   
   college_cost_f <-  cost %>% filter( field== input$field, type== input$credential, ccollege== input$ccollege) %>%
                   select( cost_total_est  )
   
   fin_aid <- 6345  #max pell grant
   costs_extras <- 3500
   
   df <- data.frame(
     supp = c("Expenses", "Expenses", "Financial Aid"),
     legend = c("Tuition", "Other School Expenses", 'Pell Grant'),
     len = c( as.numeric(college_cost_f) , costs_extras, fin_aid)
   )
   
   total_cost <- as.numeric(college_cost_f) + costs_extras
   
  balance <- as.numeric(college_cost_f) + costs_extras - fin_aid
  

  
  
   colores = c('#6B979B','#67203C','#A5BF86')
   
   ggplot(df, aes(x=supp, y=len))+
     geom_col(aes(fill = legend)) +
     scale_fill_manual(values= colores)+
     xlab( " ") +
     ylab( "dollars per year ")+
     annotate("text", x = 1, y=total_cost*1.1, label = paste("Cost of Credential: $", total_cost ))+
     annotate("text", x = 2, y=fin_aid*1.1, label = paste("Financial Aid: $", fin_aid ))+
     annotate("text", x = 1.5, y= max(fin_aid,total_cost )*1.2, label =  paste("Balance: $", balance ), color="red",  fontface =4)
     
   
   
 })
 
 
 ##### LONG TERM
 
 ###EXPORT SECTION   #############################################################################################################
 # library(blscrapeR)
 # df <- inflation_adjust(1995)
 # #inflation <- (mean(df$adj_value[(nrow(df)-10):nrow(df)]))/100
 # inflation<- 0.013
 # #inflation<- 0.013
 # #year of community college
 # year_cc <- 2
 # #--------
 # 
 # 
 # #############################################################################################################
 # # EXPENDITURES 
 # #############################################################################################################
 # 
 # #------------------------------------------------------------------------------------------------------------
 # #PERSONAL expenditures 
 # #------------------------------------------------------------------------------------------------------------   
 # library(reshape2)
 # 
 # expend_raw_long <-  melt(expend_raw, id.vars=c("county" ,  "category" , "item"  ,   "adults"))
 # 
 # personal_exp <- reactive({ expend_raw_long %>% filter(county==input$county, category=="expenditure", item=="Required annual income before taxes", adults==input$status, variable == input$children ) %>% select(value) }) 
 # 
 # personal <- reactive({ data.frame( personal= cumprod( c(personal_exp(), rep(c(1+inflation), years )))  )  })  
 # 
 # 
 # output$data <- renderTable({
 #   personal()
 # })
 # 
 # #------------------------------------------------------------------------------------------------------------
 # #COLLEGE expenditures 
 # #------------------------------------------------------------------------------------------------------------   
 # 
 # #change degree for field
 # tuition_cc <- reactive({ cost_cc %>% filter(title== input$degree, Program==input$program, Institution==input$ccollege ) %>% select("totalcost")  }) 
 # years_cc <- reactive({ cost_cc %>% filter(title== input$degree, Program==input$program, Institution==input$ccollege ) %>% select("years")  }) 
 # 
 # #  other_costs <- 3500  #other costs, including uniforms,  stetoscope, etc 
 # other_costs <- 3500  #other costs, including uniforms,  stetoscope, etc 
 # total_cc <- reactive({ tuition_cc() + other_costs }) 
 # tot_cost_cc_year <- reactive({ total_cc()/years_cc()  }) 
 # 
 # #community college expenditures: includes tuition and other costs
 # #expend_coll <- dat
 # 
 # college <-  reactive({ data.frame( college= as.numeric( c( rep(tot_cost_cc_year(), years_cc()  ), rep(0, (43 - years_cc()) )) )  )  })  
 # 
 # 
 # output$data1 <- renderTable({
 #   college()
 #   
 # })
 # 
 # #------------------------------------------------------------------------------------------------------------
 # #DEBT expenditures 
 # #------------------------------------------------------------------------------------------------------------   
 # 
 # # tuition_cc <- reactive({ cost_cc %>% filter(Institution==input$ccollege, Program==input$program, title== input$degree) %>% select("totalcost") }) 
 # # #other_costs <- 3500  #other costs, including uniforms,  stetoscope, etc 
 # # total_cc <-  reactive({ tuition_cc() +other_costs })
 # final_debt <-  reactive({ total_cc()*input$debtpercentage })
 # interest_rate <- 0.0466  #annual interest rate
 # years <- 42
 # years_debt <- 10
 # 
 # debt_pmt <- reactive({ pmt(r = interest_rate, n = years_debt, pv = final_debt(), fv = 0) })  
 # #result of payment pmt comes negative so, use negative to adjust the sign
 # debt <- reactive({ data.frame( debt= as.numeric( c( rep(0,year_cc) , rep(-debt_pmt(), years_debt), rep(0, years-year_cc -years_debt +1) ) )    )  }) 
 # 
 # output$data2 <- renderTable({
 #   debt()
 #   
 # })
 # 
 # 
 # 
 # 
 # 
 # #############################################################################################################
 # # EARNINGS 
 # #############################################################################################################
 # 
 # #------------------------------------------------------------------------------------------------------------
 # #MINIMUM WAGE EARNINGS
 # #------------------------------------------------------------------------------------------------------------   
 # #earnings_raw <- read_csv('~/Documents/STW/data/wage_county_va.csv')
 # # minwage_hour <-  earnings_raw %>% filter(county=="Arlington", category=="wage", 
 # #                           item=="Minimum Wage", adults=="1 adult") %>% select(value="0child")
 # 
 # minwage_hour <- reactive({ earnings_raw %>% filter(county==input$county, category=="wage", 
 #                                                    item=="Minimum Wage", adults=="1 adult") %>% select(value="0child")  }) 
 # 
 # index_minwage<- 0
 # hoursweek <- 43.34  #determined from MIT labwage
 # weeks <- 4
 # months <-  12
 # #initialize the matrix 1
 # 
 # minwage <- reactive({ data.frame(minwage= cumprod(c(minwage_hour()*hoursweek*weeks*months, rep(c(1+index_minwage), years ))) )   }) 
 # #minwage()
 # 
 # #------------------------------------------------------------------------------------------------------------
 # #HIGH SCHOOL EARNINGS 
 # #------------------------------------------------------------------------------------------------------------   
 # #earnings_acs <- read_csv('~/Documents/STW/data/earnings.csv')
 # 
 # #earnings_hs <- earnings_acs %>% filter(county =="Arlington") %>% select(earnings_hs) 
 # earnings_hs <- reactive({ earnings_acs %>% filter(county ==input$county) %>% select(earnings_hs)  })  
 # earngr_hs <- 0.018   #growht of earnings for hs 2012-2018
 # highschool <- reactive({ data.frame( highschool= cumprod(c( earnings_hs() , rep(c(1+earngr_hs), years ))) )    })    #revise the growth PENDIENTE
 # 
 # 
 # 
 # #------------------------------------------------------------------------------------------------------------
 # #ASSOCIATE EARNINGS 
 # #------------------------------------------------------------------------------------------------------------   
 # # earnings_cc_career <-  earnings_cc %>% filter(college== 'Northern Virginia Community College') %>%
 # #   #filter(years==1.5) %>% filter( program == 'input$career' ) %>%  select(wagemedian)
 # #   filter( program == "Registered Nursing/Registered Nurse" ) %>% filter(years==1.5) %>% select(wagemedian)
 # 
 # # earnings_cc_career <- reactive({ earnings_cc %>% filter(college== input$ccollege) %>%
 # #     filter( program == input$degree ) %>% filter(years==1.5) %>% select(wagemedian)  }) 
 # earnings_cc_career <- reactive({ earnings_cc %>% filter(college== input$ccollege,  years==1.5, program == input$job) %>% select(wagemedian)  }) 
 # 
 # earngr_assoc <- 0.01   #growht of earnings for hs 2012-2018
 # 
 # assoc0 <- reactive({ data.frame( assoc0 = cumprod(c(earnings_cc_career() , rep(c(1+earngr_assoc), years )))  ) })  
 # assoc <- reactive({  data.frame( assoc = c(0,0, assoc0()[3:43,1] )  )     })
 # 
 # 
 # output$data33 <- renderTable({
 #   # assoc()[1,1] <- 0
 #   # assoc()[2,1] <- 0
 #   assoc()
 #   
 # }) 
 # 
 # 
 # #------------------------------------------------------------------------------------------------------------
 # #JOIN DATA - expenditures 
 # #------------------------------------------------------------------------------------------------------------   
 # 
 # dat_plot <- reactive({ cbind(personal(), college(), debt(), minwage(), highschool(), assoc() ) }) 
 # 
 # 
 # output$data3 <- renderTable({
 #   
 #   highschool()
 #   
 # }) 
 # 
 # #--------------------------------------------------------
 # #PLOT
 # #-------------------------------------------------------- 
 # 
 # 
 # output$plot <- renderPlotly({
 #   
 #   colors <- c("Personal Expenses"="darkred", 
 #               "College Expenses"= "red",
 #               "Debt"="orange", 
 #               "Minimum Wage Earnings"= "yellow4",
 #               "High School Earnings"="royalblue3",
 #               "Associate Earnings"="blue"
 #   )
 #   
 #   
 #   plot1 <- ggplot(dat_plot(), aes(x= seq(0,years) ) ) +
 #     
 #     geom_line(aes(y = personal , color = "Personal Expenses" ), size=0.6, alpha=1 ) +
 #     geom_line(aes(y = minwage , color = "Minimum Wage Earnings" ), size=0.6, alpha=1 ) +
 #     geom_line(aes(y = highschool , color = "High School Earnings" ), size=0.6, alpha=1 ) +
 #     #geom_line(aes(y = assoc , color = "Associate Earnings" ), size=0.6, alpha=1 ) +
 #     
 #     labs(x = "Years",
 #          y = "Dollars",
 #          color = "Legend") +
 #     scale_color_manual(values = colors) +
 #     ggtitle("Personal Expenses and Earnings for 40 years")+
 #     theme(plot.title = element_text(hjust = 0.5)) +
 #     scale_x_continuous(breaks= seq(0, years, by = 5)) +
 #     scale_y_continuous( breaks=seq( 0, 130000, by = 10000 ) , labels = comma)
 #   #max(dat_plot())
 #   plot1
 #   
 #   #--- new 
 #   
 #   if(input$earnings_career == TRUE){
 #     plot1 <- plot1 +
 #       geom_line(aes(y = assoc , color = "Associate Earnings" ), size=0.6, alpha=1 )
 #     
 #   }
 #   
 #   plot1
 #   #-----   
 #   
 #   if(input$ccpayment == TRUE){
 #     plot1 <- plot1 +
 #       geom_line(aes(y = personal+ college , color = "College Expenses" ), size=0.6, alpha=1 )
 #     
 #   }
 #   
 #   plot1
 #   
 #   if(input$debt == TRUE){
 #     plot1 <-plot1 +
 #       geom_line(aes(y = personal+ debt , color = "Debt" ), size=0.6, alpha=1 )
 #   }
 #   
 #   plot1
 #   
 # })
 # 
 # 
 # #Text
 # 
 # #add text
 # output$text <- renderText({
 #   paste("First year:",
 #         tot_cost_cc_year(),
 #         "Second year: $", 
 #         tot_cost_cc_year() )
 #   
 # })
 # 
 # #how much per year if loan 
 # 
 # output$text_payment <- renderText({
 #   paste("Anual payment:",
 #         round(-debt_pmt() , 2)
 #   )
 #   
 # })
 # 
 ###   END EXPORT ##################################################################################################################
 
 
}

shinyApp(ui, server)
