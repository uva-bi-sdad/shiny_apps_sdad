##### These are helpful links I used to create the shiny app ##### 
#https://shiny.rstudio.com/articles/layout-guide.html LAYOUT
#https://shiny.rstudio.com/articles/persistent-data-storage.html PERSISTENT STORAGE
#https://stat.ethz.ch/pipermail/r-help/2017-June/447450.html This is for styling RMarkdown file
#https://gupsych.github.io/tquant/data-input.html This is the solution for the saving checkbox group issue
#https://cran.r-project.org/web/packages/vcd/vignettes/strucplot.pdf this is helpful for mosaic plots
#https://stackoverflow.com/questions/36132204/reactive-radiobuttons-with-tooltipbs-in-shiny  This is the solution to the checkbox individual id issues


# You should un-comment the following and create two folders using the code below to store the feedback and form data.
# I re-comment this after running so that I only create the folder once.

#dir.create("feedback")
#dir.create("form")

#if you do not have these packages, use install.packages("")
library(shiny)
library(DT) 
library(ggplot2)  
library(stringi)
library(stringr)
# library(gtools)
library(vcd)
library(tidyr)
library(dplyr)
library(shinythemes)
library(markdown)
# library(convertGraph)
# library(jpeg)
# library(tableHTML)


##### THEME COLORS #####
theme_Palette<-c("#1B3766", "#02ABD6", "#6DD4DB", "#A9D5A5", "#F17E1D", "#FDDA24", "#EF3F6B","#25CAD3","#FDBC00", "#62BB46")
wheel <- function(col, radius = 1, ...)
  pie(rep(1, length(col)), col=col, radius=radius)
wheel(theme_Palette)

##### DATA #####

responses <- read.csv("data-discovery-aug-27.csv", sep = ",",stringsAsFactors = FALSE, header=TRUE, encoding="UTF-8")
responses<-responses[!apply(responses == "", 1, all),] #remove empty rows
names(responses) <- stri_trim(gsub("..Yes.No.|i\\.e\\..+or\\.|i\\.e\\..+|\\.{53}.+|\\.+", " ", names(responses)), side = "right")
colnames(responses)[colnames(responses)== "Cost Price"] <- "Price"
colnames(responses)[colnames(responses)== "When does the data become available"] <- "Data Availability Schedule"
colnames(responses)[colnames(responses)== "Can the data be trended"] <- "Trended Data"
colnames(responses)[colnames(responses)== "Data Quality Assessments Potential biases Potential statistical surveys for comparison"] <- "Data Quality Assessments"
colnames(responses)[colnames(responses)== "Funding amount to support R D"] <- "R & D Funding"

# Expand Responses for Visualization of Checkbox Group Items #
expand_responses <- responses
expand_responses[["Subject"]] <- trimws(expand_responses[["Subject"]])
expand_responses[["Subject"]] <- as.list(str_split(expand_responses[["Subject"]], ", "))
expand_responses <- expand_responses %>% unnest("Subject") %>% group_by(`Data Source Name`, `Dataset Name`)
expand_responses <- as.data.frame(expand_responses)

expand_responses[["Data Type"]] <- trimws(expand_responses[["Data Type"]])
expand_responses[["Data Type"]] <- as.list(str_split(expand_responses[["Data Type"]], ", "))
expand_responses <- expand_responses %>% unnest("Data Type") %>% group_by(`Data Source Name`, `Dataset Name`)
expand_responses <- as.data.frame(expand_responses)




##### This function allows tooltips for checkbox items on the data sources tab (see stackoverflow link for further information)#####
radioTooltip <- function(id, choice, title, placement = "bottom", trigger = "hover", options = NULL){
  options = shinyBS:::buildTooltipOrPopoverOptionsList(title, placement, trigger, options)
  options = paste0("{'", paste(names(options), options, sep = "': '", collapse = "', '"), "'}")
  bsTag <- shiny::tags$script(shiny::HTML(paste0("
                                                 $(document).ready(function() {
                                                 setTimeout(function() {
                                                 $('input', $('#", id, "')).each(function(){
                                                 if(this.getAttribute('value') == '", choice, "') {
                                                 opts = $.extend(", options, ", {html: true});
                                                 $(this.parentElement).tooltip('destroy');
                                                 $(this.parentElement).tooltip(opts);
                                                 }
                                                 })
                                                 }, 500)
                                                 });
                                                 ")))
  htmltools::attachDependencies(bsTag, shinyBS:::shinyBSDep)
}

##### UI #####
ui <- fluidPage(
 #theme = shinytheme("cosmo"),

  HTML('<script src="//use.typekit.net/tgy5tlj.js"></script>'),
  HTML('<script>try{Typekit.load();}catch(e){}</script>'),
  theme = "theme.css",
  title = "Data Discovery",

  h2(fluidRow(column(3, tags$a(href="https://biocomplexity.virginia.edu/", 
                        tags$img(class = "BII-logo", src="BII.jpg", title="BII Link", align = "left"))),
              column(6, p(style = "margin-top: 10px;  line-height: 35px;", tags$span(style= "color:#1B3766;", "Skilled Technical Workforce")), 
                        p(style = "line-height: 5px;", 
                          tags$span(style= "color:#F17E1D; font-family: bodoni-urw, serif; font-weight: 900; font-style: italic;
                                            font-size: 30px; text-transform: uppercase;", "Data Discovery"))),
              column(3, tags$a(href="https://www.nsf.gov/statistics/",
                               tags$img(class = "NSF-logo", src='nsf-ncses.png', align = 'right')))
    )),



hr(),
  #mainPanel(

    tabsetPanel(
      id = 'dataset',
      tabPanel(h4("About"), includeMarkdown("welcome-page.Rmd")), # you will need to include the path to the "welcome-page.Rmd"
      tabPanel(h4("Data Sources"),

              fluidRow(
                column(style = "margin-top: 15px;", 12, "This page provides a data table with information about each data source. 
                       You may filter the variables displayed in the data table by selecting the boxes on the left-hand side. 
                       To search within columns, use the search bars directly below the column name, or search the entire data sheet by using the search bar at the top of the tab.
                                      The Excel and CSV buttons export the data table.")),
               hr(),
               sidebarPanel(
                 checkboxGroupInput("show_vars", "Columns to Show:", 
                                    choiceNames=names(responses), 
                                    choiceValues = names(responses),
                                    selected=names(responses)), 
                 width=2), 
               # the following lines create the hover tooltip for the checkboxes on the Data Sources tab.
                     radioTooltip(id = "show_vars", choice = "Data Source Name", title = " An organization collecting the data and link to the organization.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Credentials", title = "Indicates if the dataset includes information on credentials.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Skills", title = "Indicates if the dataset includes information on skills.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Jobs", title = "Indicates if the dataset includes information on jobs.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Employers", title = "Indicates if the dataset includes information on employers.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "STW Relevant", title = "A description of how the data source can be used to describe the STW.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Dataset Name", title = "An organization’s name for the dataset and link to the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Dataset Link", title = "A link, if available, to the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Subject", title = "The main topic(s) addressed in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Organization Type", title = "Indicates if the organization providing the dataset is for-profit, non-profit, or federal.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Data Type", title = "Describes the data by broad method(s) used for collection.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Purpose", title = "A brief explanation of the purpose and history of the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Audience", title = "Lists the main users of the dataset, or for whom the dataset was compiled.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Population Coverage", title = "Description of the target population and observations in the sample or population.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Unit of Analysis", title = "The smallest unit in the dataset on which information is provided.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Geographic Unit", title = "A list of all geographic variables contained in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Time Coverage", title = "The start and end date of the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Collection Frequency", title = "Indicates how often the data is collected.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "When does the data become available", title = "Indicates how frequently new data are made available.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Can the data be trended", title = "Indicates if the dataset can be trended.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Methodology Report Link", title = "A link, if available, to the methodology report for the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Data Dictionary Link", title = "A link, if available, to the data dictionary for the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Data Quality Assessments", title = "A description including biases and issues of the dataset and if the dataset can be benchmarked against an existing survey.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Cost Price", title = "Lists any fees for using the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Funding amount to support R D", title = "Lists any funding provided by the organization for uses of the dataset that support R&D.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Licensing or Training Required", title = "Indicates if licensing or training is required for use of the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Accessibility", title = "Method(s) of acquiring data.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Data Format", title = "The format(s) in which the data is available.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Individuals Identifiable", title = "Indicates if personally identifiable information is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Gender", title = " Indicates if information on gender is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Race Ethnicity", title = "Indicates if information on race or ethnicity is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Persons with Disabilities", title = "Indicates if information on persons with disabilities is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Veterans", title = "Indicates if information on veterans is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Active military and their families", title = "Indicates if information on active military is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Persons who live on tribal lands", title = "Indicates if information on tribal lands is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Fields of Study", title = "Indicates if information on field of study or types of training is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Types of Employment or Occupations", title = "Indicates if information on employment or occupations is included in the dataset.", placement = "right", trigger = "hover"),
                     radioTooltip(id = "show_vars", choice = "Notes", title = "Any additional information relevant to the data source.", placement = "right", trigger = "hover"),
                mainPanel( DT::dataTableOutput("mytable1"), width = 10)), 
      tabPanel( h4("Plot"), 
                fluidRow(
                  column(style = "margin-top: 15px;", 12, "This tab displays charts describing 
                         various categorical variables from the data sources table. 
                         You may select one to three variables buttons and drop-down lists below.")),
                hr(),
                
             fluidRow(
               column(3, uiOutput("filter_vars") ), 
               column(9, uiOutput("select_vars"))), br(),
             fluidRow(uiOutput("plot"), align ="center")
             ),  

      tabPanel(h4("Dictionary"), fluidRow(
        column(style = "margin-top: 15px;", 12)),includeMarkdown("data-dictionary.Rmd")), # you will need to include the path to the "data-dictionary.Rmd"

      tabPanel(h4("Contact"), 
               fluidRow(
                 column(style = "margin-top: 15px;", 12, 
                        p("For corrections, additions, or questions about the data sources please contact:", br(),
                        "Vicki A Lancaster, Principal Scientist", br(),
                       tags$a(href="mailto:val7zv@virginia.edu", "val7zv@virginia.edu"), br(),
                        "Social & Decision Analytics Division", br(), 
                        "Biocomplexity Institute & Initiative", br(), 
                        "University of Virginia", br(),  
                        "Suite 2910, 1100 Wilson Blvd, Arlington, VA 22209")))
             )
    )
 )




##### SERVER #####
server <- function(input, output, session) {
  # This outputs the reactive data table on the Data Sources tab
  output$mytable1 <- DT::renderDataTable({
    DT::datatable(responses[, input$show_vars, drop = FALSE],  
                  filter = "top",
                  extensions = c('Buttons', 'FixedHeader'),
       
                  
                  options = list(
                   #fixedHeader = TRUE,
                    autoWidth = FALSE,
                     buttons = list(
                      list(extend='csv',
                        filename = 'STW-Data-Discovery'),
                      list(extend='excel',
                       filename = 'STW-Data-Discovery')), dom="BlfrtipS", iDisplayLength=-1
                     ))
  })

  #This allows filtering between one, two and three variables on the Plots tab
  output$filter_vars <- renderUI({
    radioButtons("rd","Select Option", choices = c("One Variable","Two Variables", "Three Variables"),
                 selected = "One Variable")
  })
  
  #Designates the variable choices on the drop down menus on the Plots tab
  output$select_vars <- renderUI({
    req(input$rd)
    if (input$rd == "One Variable") {fluidRow(column(width = 4,
      selectInput("category1", "Variable", choices=c("Credentials","Jobs", "Employers", "Skills", "Subject", "Organization Type", "Data Type", "Gender", "Race Ethnicity",  "Persons with Disabilities", "Veterans", "Active military and their families", "Persons who live on tribal lands", "Fields of Study", "Types of Employment or Occupations"))))
    }
    else if(input$rd == "Two Variables") {fluidRow(column(width = 4, 
      selectInput("category2", "Variable 1", choices=c("Credentials","Jobs", "Employers", "Skills", "Subject", "Organization Type", "Data Type", "Gender", "Race Ethnicity",  "Persons with Disabilities", "Veterans", "Active military and their families", "Persons who live on tribal lands", "Fields of Study", "Types of Employment or Occupations"))),
      column(width = 4, selectInput("category3", "Variable 2", choices=c("Credentials","Jobs", "Employers", "Skills", "Subject", "Organization Type", "Data Type", "Gender", "Race Ethnicity",  "Persons with Disabilities", "Veterans", "Active military and their families", "Persons who live on tribal lands", "Fields of Study", "Types of Employment or Occupations" ))))
    }
    else if(input$rd == "Three Variables"){fluidRow(
      column(width = 4, selectInput("category4", "Variable 1", choices=c("Credentials","Jobs", "Employers", "Skills", "Subject", "Organization Type", "Data Type", "Gender", "Race Ethnicity",  "Persons with Disabilities", "Veterans", "Active military and their families", "Persons who live on tribal lands", "Fields of Study", "Types of Employment or Occupations" ))),
      column(width = 4, selectInput("category5", "Variable 2", choices=c("Credentials","Jobs", "Employers", "Skills", "Subject", "Organization Type", "Data Type", "Gender", "Race Ethnicity",  "Persons with Disabilities", "Veterans", "Active military and their families", "Persons who live on tribal lands", "Fields of Study", "Types of Employment or Occupations"))),
      column(width = 4, selectInput("category6", "Variable 3", choices=c("Credentials","Jobs", "Employers", "Skills", "Subject", "Organization Type", "Data Type", "Gender", "Race Ethnicity",  "Persons with Disabilities", "Veterans", "Active military and their families", "Persons who live on tribal lands", "Fields of Study", "Types of Employment or Occupations"))))
    }
  })
  
  # This displays the plots
  output$plot <- renderUI({
    #browser()
    
    req(input$rd)
    
    if(input$rd=="One Variable") {
      
        req(input$category1)
          
          output$plot1<-renderPlot({
            
            ggplot(expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category1)]), ], 
                   aes(x = expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category1)]), input$category1] , 
                              fill = expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name',input$category1)]), input$category1]))+
              geom_bar(width = 0.5) +
              scale_fill_manual(values= c(theme_Palette[1],theme_Palette[5], theme_Palette[2],theme_Palette[4],
                                    theme_Palette[3],theme_Palette[6],theme_Palette[7],theme_Palette[8], theme_Palette[9], theme_Palette[10])) +
              theme_minimal() +
              labs(title = paste("Data Sources Containing", input$category1), y = "Number of Sources", x = "")+
              theme(
                legend.position = "none", 
                plot.title = element_text(hjust = 0.5, size = 24, face = "bold"),
                axis.text.x = element_text(size = 18, 
                                           angle = ifelse(input$category1 == "Subject"|input$category1 == "Data Type", 20, 0)),
                axis.text.y = element_text(size = 18), 
                axis.title.x = element_text(size = 18), 
                axis.title.y = element_text(size = 18))
          })
          
              plotOutput("plot1", height = 600, width = 1000)
      
    } else if(input$rd=="Two Variables"){
      
      req(input$category2)
      req(input$category3)
      
              output$plot2<-renderPlot({ 
          
                ggplot(expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category2, input$category3)]), ], 
                       aes(x = expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category2, input$category3)]), input$category2], 
                           fill = expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category2, input$category3)]), input$category3]))+
                  geom_bar(width = 0.50) +
                  theme_minimal() +
                  scale_fill_manual(values= c(theme_Palette[1],theme_Palette[5], theme_Palette[2],theme_Palette[4],
                                              theme_Palette[3],theme_Palette[6],theme_Palette[7],theme_Palette[8], 
                                              theme_Palette[9], theme_Palette[10])) +
                  labs(title = paste("Data Sources Containing", input$category3, "by", input$category2), y = "Number of Sources", x = paste(input$category2), fill = paste(input$category3)) +
                  theme(legend.position = c(.99, .95),
                        legend.justification = c("right", "top"),
                        legend.box.just = "right",
                        legend.margin = margin(6, 6, 6, 6),
                        plot.title = element_text(hjust = 0.5, size = 24, face = "bold"),
                        axis.text.x = element_text(size = 18,
                                             angle = ifelse(input$category2== "Subject"|input$category2 == "Data Type", 20, 0)),
                        axis.text.y = element_text(size = 18), 
                        axis.title.x = element_text(size = 18), 
                        axis.title.y = element_text(size = 18))
              }, width= 1000, height= 600)
                plotOutput("plot2")
         
             
    } else if(input$rd=="Three Variables"){
      
      req(input$category4)
      req(input$category5)
      req(input$category6)
      
if((n_distinct(expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), input$category4])==2) & 
   (n_distinct(expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), input$category5])==2) & 
   (n_distinct(expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), input$category6])==2)){  
               
            output$plot3<-renderPlot({
  
                  var1 <- expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), input$category4]
                  var2 <- expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), input$category5]
                  var3 <- expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), input$category6]
    
    
                  mosaic(xtabs(~ var1 + var2 + var3  ), data = expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), ], margin = c(3, 10, 2, 10),
                           shade = T,  gp = gpar(fill = c(theme_Palette[1], theme_Palette[2], theme_Palette[2], theme_Palette[9], theme_Palette[2], theme_Palette[9], theme_Palette[9], theme_Palette[5])), 
                           main = paste("Data Containing ", input$category4, ", ", input$category5, ", and ", input$category6, sep = ""),
                           labeling_args = list(set_varnames = c(var1 = input$category4, var2 = input$category5, var3 = input$category6), 
                                                rot_labels = c(0, 0, 90), offset_varnames = c(0,1,0, 1)
                           ))
          }, height = 600, width = 800)
            plotOutput("plot3")
            
          } else {
            output$plot8<-renderPlot({ 
              
              ggplot(expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), ], 
                     aes(x = expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), 
                                              if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                                                 (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                                                input$category5
                                                
                                              } else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                                                        (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                                                input$category6
                                              } else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                                                         (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                                                input$category4
                                              } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                                                        (input$category4== "Data Type" & input$category5 == "Data Type")|
                                                        (input$category4== "Subject" & input$category5 == "Data Type")|
                                                        (input$category4== "Subject" & input$category5 == "Subject")){
                                                input$category6
                                              } else if((input$category5== "Data Type" & input$category6 == "Subject")|
                                                        (input$category5== "Data Type" & input$category6 == "Data Type")|
                                                        (input$category5== "Subject" & input$category6 == "Data Type")|
                                                        (input$category5== "Subject" & input$category6 == "Subject")){
                                                input$category4
                                              } else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                                                         (input$category6== "Data Type" & input$category4 == "Data Type")|
                                                         (input$category6== "Subject" & input$category4 == "Data Type")|
                                                         (input$category6== "Subject" & input$category4 == "Subject")){
                                                input$category5
                                              } else{
                                                input$category4
                                              }
                                              ], 
                         
                         
                         fill =expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), 
                                                if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                                                   (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                                                  input$category6
                                                }else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                                                         (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                                                  input$category4
                                                }else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                                                          (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                                                  input$category5
                                                } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                                                          (input$category4== "Data Type" & input$category5 == "Data Type")|
                                                          (input$category4== "Subject" & input$category5 == "Data Type")|
                                                          (input$category4== "Subject" & input$category5 == "Subject")){
                                                  input$category4
                                                }else if((input$category5== "Data Type" & input$category6 == "Subject")|
                                                         (input$category5== "Data Type" & input$category6 == "Data Type")|
                                                         (input$category5== "Subject" & input$category6 == "Data Type")|
                                                         (input$category5== "Subject" & input$category6 == "Subject")){
                                                  input$category5
                                                }else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                                                          (input$category6== "Data Type" & input$category4 == "Data Type")|
                                                          (input$category6== "Subject" & input$category4 == "Data Type")|
                                                          (input$category6== "Subject" & input$category4 == "Subject")){
                                                  input$category6
                                                } else{
                                                  input$category5
                                                }
                                                
                                                
                                                ]))+
                
                
                facet_grid(~expand_responses[!duplicated(expand_responses[,c('Dataset Name', 'Data Source Name', input$category4, input$category5, input$category6)]), 
                                             
                                             if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                                                (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                                               input$category4
                                             }else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                                                      (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                                               input$category5
                                             }else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                                                       (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                                               input$category6 
                                             } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                                                       (input$category4== "Data Type" & input$category5 == "Data Type")|
                                                       (input$category4== "Subject" & input$category5 == "Data Type")|
                                                       (input$category4== "Subject" & input$category5 == "Subject")){
                                               input$category5
                                             }else if((input$category5== "Data Type" & input$category6 == "Subject")|
                                                      (input$category5== "Data Type" & input$category6 == "Data Type")|
                                                      (input$category5== "Subject" & input$category6 == "Data Type")|
                                                      (input$category5== "Subject" & input$category6 == "Subject")){
                                               input$category6
                                             }else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                                                       (input$category6== "Data Type" & input$category4 == "Data Type")|
                                                       (input$category6== "Subject" & input$category4 == "Data Type")|
                                                       (input$category6== "Subject" & input$category4 == "Subject")){
                                               input$category4
                                             } else{
                                               input$category6
                                             }
                                             
                                             
                                             
                                             ])+
                geom_bar(width = 0.50) +
                theme_minimal() +
                scale_fill_manual(values= c(theme_Palette[1],theme_Palette[5], theme_Palette[2],theme_Palette[4],
                                            theme_Palette[3],theme_Palette[6],theme_Palette[7],theme_Palette[8], 
                                            theme_Palette[9], theme_Palette[10])) +
                labs(title = paste("Data Sources Containing",  if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                                                                  (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                  input$category6
                }else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                         (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                  input$category4
                }else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                          (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                  input$category5
                } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                          (input$category4== "Data Type" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Subject")){
                  input$category4
                }else if((input$category5== "Data Type" & input$category6 == "Subject")|
                         (input$category5== "Data Type" & input$category6 == "Data Type")|
                         (input$category5== "Subject" & input$category6 == "Data Type")|
                         (input$category5== "Subject" & input$category6 == "Subject")){
                  input$category5
                }else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                          (input$category6== "Data Type" & input$category4 == "Data Type")|
                          (input$category6== "Subject" & input$category4 == "Data Type")|
                          (input$category6== "Subject" & input$category4 == "Subject")){
                  input$category6
                } else{
                  input$category5
                }, "by", if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                            (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                  input$category5
                  
                } else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                          (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                  input$category6
                } else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                           (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                  input$category4
                } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                          (input$category4== "Data Type" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Subject")){
                  input$category6
                } else if((input$category5== "Data Type" & input$category6 == "Subject")|
                          (input$category5== "Data Type" & input$category6 == "Data Type")|
                          (input$category5== "Subject" & input$category6 == "Data Type")|
                          (input$category5== "Subject" & input$category6 == "Subject")){
                  input$category4
                } else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                           (input$category6== "Data Type" & input$category4 == "Data Type")|
                           (input$category6== "Subject" & input$category4 == "Data Type")|
                           (input$category6== "Subject" & input$category4 == "Subject")){
                  input$category5
                } else{
                  input$category4
                }, "and", if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                             (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                  input$category4
                }else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                         (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                  input$category5
                }else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                          (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                  input$category6 
                } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                          (input$category4== "Data Type" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Subject")){
                  input$category5
                }else if((input$category5== "Data Type" & input$category6 == "Subject")|
                         (input$category5== "Data Type" & input$category6 == "Data Type")|
                         (input$category5== "Subject" & input$category6 == "Data Type")|
                         (input$category5== "Subject" & input$category6 == "Subject")){
                  input$category6
                }else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                          (input$category6== "Data Type" & input$category4 == "Data Type")|
                          (input$category6== "Subject" & input$category4 == "Data Type")|
                          (input$category6== "Subject" & input$category4 == "Subject")){
                  input$category4
                } else{
                  input$category6
                }), y = "Number of Sources", x = paste(if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                                                          (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                  input$category5
                  
                } else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                          (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                  input$category6
                } else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                           (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                  input$category4
                } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                          (input$category4== "Data Type" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Subject")){
                  input$category6
                } else if((input$category5== "Data Type" & input$category6 == "Subject")|
                          (input$category5== "Data Type" & input$category6 == "Data Type")|
                          (input$category5== "Subject" & input$category6 == "Data Type")|
                          (input$category5== "Subject" & input$category6 == "Subject")){
                  input$category4
                } else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                           (input$category6== "Data Type" & input$category4 == "Data Type")|
                           (input$category6== "Subject" & input$category4 == "Data Type")|
                           (input$category6== "Subject" & input$category4 == "Subject")){
                  input$category5
                } else{
                  input$category4
                }), fill = paste(if((input$category4== "Data Type" & input$category5 != "Subject" & input$category6 != "Subject")|
                                    (input$category4== "Subject" & input$category5 != "Data Type" & input$category6 != "Data Type")){
                  input$category6
                }else if((input$category5== "Data Type" & input$category4 != "Subject" & input$category6 != "Subject") |
                         (input$category5== "Subject"& input$category4 != "Data Type" & input$category6 != "Data Type")){
                  input$category4
                }else if ((input$category6== "Data Type" & input$category5 != "Subject" & input$category4 != "Subject") |
                          (input$category6== "Subject" & input$category5 != "Data Type" & input$category4 != "Data Type")){
                  input$category5
                } else if((input$category4== "Data Type" & input$category5 == "Subject")|
                          (input$category4== "Data Type" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Data Type")|
                          (input$category4== "Subject" & input$category5 == "Subject")){
                  input$category4
                }else if((input$category5== "Data Type" & input$category6 == "Subject")|
                         (input$category5== "Data Type" & input$category6 == "Data Type")|
                         (input$category5== "Subject" & input$category6 == "Data Type")|
                         (input$category5== "Subject" & input$category6 == "Subject")){
                  input$category5
                }else if( (input$category6== "Data Type" & input$category4 == "Subject")|
                          (input$category6== "Data Type" & input$category4 == "Data Type")|
                          (input$category6== "Subject" & input$category4 == "Data Type")|
                          (input$category6== "Subject" & input$category4 == "Subject")){
                  input$category6
                } else{
                  input$category5
                })) +
                theme(legend.position = "bottom",
                      strip.text.x = element_text(size = 12),
                      plot.title = element_text(hjust = 0.5, size = 24, face = "bold"),
                      axis.text.x = element_text(size = 18),
                      axis.text.y = element_text(size = 18), 
                      axis.title.x = element_text(size = 18), 
                      axis.title.y = element_text(size = 18))
              
            }, height = 600, width = 1200)
            plotOutput("plot8")
     }
 
  }
})
  
  
}

shinyApp(ui, server)
